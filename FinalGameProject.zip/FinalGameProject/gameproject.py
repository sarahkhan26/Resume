# Sarah Khan (jwe6pe)
# Iman Mohamed (mmn2zz)

# Game Description: Our game is a spin-off the popular app "Snake vs Block". It is a two-player game where each
# races against each other to reach the end and "save their kingdom" . There are lines of barriers blocking
# the character way. Each character is  assigned a specific color which corresponds to colors on the blockade.
# In order to get through the blockade, each character will have to "hit" the part of the blockade that corresponds with
# their color. The number of "hits" it'll take to break the blockade is constant. Once the part of the blockade is
# broken, the character can progress. If one player is behind the other and the screen moves past them, that character
# loses. There will also be a timer going on, so if both characters don't collect the potion  by the time the timer
# finishes, they both lose. Otherwise, whichever character reaches the end first, wins the game.
# The premise of the game will be that both these characters are racing towards the end of the screen to be a hero.
# They have to reach the end of the screen before the timer finishes to collect a special potion otherwise it'll mean
# the end of the world ("game over").

# Basic Features:
# Input: The game uses the keyboard to incorporate user input. The "W","A","S", and "D" keys can be used to
# maneuver Player Two up, left, right, and down, respectively, and the up, left right, and down keys can be used to
# make Player One move in those directions. The "Q" key will be used to make Player Two hit the blockade, and the "/"
# key can be used to make Player One hit the blockade. The blockade can only take "damage" when the players are
# simultaneously touching the blockade and hitting their designated hit key.
# Game over: The game is over when either one player collects the potion, or the timer runs out. When one
# player collects the potion, they will become the winner, and the game will be over. However, if neither player
# collects the potion by the time the timer runs out, both players lose and the game is over. The game is also over
# if one of the characters is off-screen. The character that is on screen will win, and the character that is off-screen
# and behind, will lose.
# Graphics: Sprites are being used for each player, and there are designated spots on the blockades that correspond to
# the color of each player, which the player has to hit in order to break through it. The level will scroll through
# multiple blockades of similar nature before reaching the end. There will also be a background image in the game of
# some sort of greenery or path to add to the context of the game. There also is an image of a potion that represents
# what the characters are racing towards.

# Additional Features:
# Sprite Animation: There are sprites for each character that will signify the movement (i.e. running/attacking)
# that each player takes.
# Scrolling Level: The screen moves at a constant rate and features different blockades. The background of the screen
# is similar to green ruins to match with the context of the game.
# Timer: There is a timer at the top of the screen indicating how much time both players have to reach the
# end of the screen before its "game-over".
# Two-Player: There are two characters in this game, the heros, that need to be played by two different players.

import uvage

camera_w = 800
camera_l = 600
camera = uvage.Camera(camera_w, camera_l)

# Game borders
topwall = uvage.from_color(0, 0, "white", 1000000000000000, 1)
bottomwall = uvage.from_color(0, 600, "white", 1000000000000000, 1)
leftwall = uvage.from_color(0, 0, "white", 1, 1000000000000000)
rightwall = uvage.from_color(800, 600, "white", 1, 1000000000000000)

# Game instructions
instructions = uvage.from_text(400, 170, "Instructions", 30, "white")
instructions1 = uvage.from_text(400, 210, "Help your knight be the first to retrieve the potion and save the kingdom",
                                20, "white")
instructions2 = uvage.from_text(400, 230, "before the opposing knight gets to it or the timer runs out!", 20, "white")
instructions3 = uvage.from_text(400, 270,
                                "Gray Knight Controls: Up arrow moves up, down arrow moves down, left arrow moves left",
                                20, "white")
instructions4 = uvage.from_text(400, 290,
                                "and right arrow moves right. The '/' can be used to break gray blockade pieces.", 20,
                                "white")
instructions5 = uvage.from_text(400, 330, "Pink Knight Controls: 'W' moves up, 'D'  moves down, 'A'  moves left", 20,
                                "white")
instructions6 = uvage.from_text(400, 350, "and  'D' moves right. The 'S' can be used to break pink blockade pieces.",
                                20, "white")
instructions7 = uvage.from_text(400, 410, "Press the space bar to clear the screen!", 30, "white")
instructions_box = uvage.from_color(400, 300, "black", 600, 300)

# Scrolling background
background = uvage.from_image(400, 300, "Battleground1.png")
background.size = [800, 600]
background2 = uvage.from_image(1200, 300, "Battleground1.png")
background2.size = [800, 600]
background3 = uvage.from_image(2000, 300, "Battleground1.png")
background3.size = [800, 600]
background4 = uvage.from_image(2800, 300, "Battleground1.png")
background4.size = [800, 600]

# Running sprite sheets
player1_run_sheet = uvage.load_sprite_sheet("Run1.png", 1, 7)
player2_run_sheet = uvage.load_sprite_sheet("Run3.png", 1, 7)
player1_run = uvage.from_image(300, 200, player1_run_sheet[1])
player2_run = uvage.from_image(300, 400, player2_run_sheet[1])
player1_run_current_frame = 0
player2_run_current_frame = 0
player1_move = False
player2_move = False

# Attacking sprite sheets
player1_attack_sheet = uvage.load_sprite_sheet("Attack21.png", 1, 4)
player2_attack_sheet = uvage.load_sprite_sheet("Attack23.png", 1, 4)
player1_attack_current_frame = 0
player2_attack_current_frame = 0
player1_move2 = False
player2_move2 = False

# Idle sprite sheets
player1_idle_sheet = uvage.load_sprite_sheet("Idle1.png", 1, 4)
player2_idle_sheet = uvage.load_sprite_sheet("Idle3.png", 1, 4)

# Moving right vs moving left
player1_move_right = True
player2_move_right = True

# Potion sprite
potion = uvage.from_image(1500, 300, "Potion.png")
potion.scale_by(1.5)

# Black blockades
black_blockades = [
    # Wall 1
    uvage.from_image(400, 300, "black_blockade.png"),
    uvage.from_image(400, 225, "black_blockade.png"),
    uvage.from_image(400, 475, "black_blockade.png"),
    uvage.from_image(400, 560, "black_blockade.png"),
    uvage.from_image(400, 5, "black_blockade.png"),
    uvage.from_image(400, 40, "black_blockade.png"),
    # Wall 2
    uvage.from_image(600, 400, "black_blockade.png"),
    uvage.from_image(600, 480, "black_blockade.png"),
    uvage.from_image(600, 555, "black_blockade.png"),
    uvage.from_image(600, 220, "black_blockade.png"),
    uvage.from_image(600, 35, "black_blockade.png"),
    # Wall 3
    uvage.from_image(800, 145, "black_blockade.png"),
    uvage.from_image(800, 225, "black_blockade.png"),
    uvage.from_image(800, 305, "black_blockade.png"),
    uvage.from_image(800, 355, "black_blockade.png"),
    uvage.from_image(800, 540, "black_blockade.png"),
    uvage.from_image(800, 600, "black_blockade.png"),
    # Wall 4
    uvage.from_image(1000, 300, "black_blockade.png"),
    uvage.from_image(1000, 225, "black_blockade.png"),
    uvage.from_image(1000, 475, "black_blockade.png"),
    uvage.from_image(1000, 560, "black_blockade.png"),
    uvage.from_image(1000, 5, "black_blockade.png"),
    uvage.from_image(1000, 40, "black_blockade.png"),
    # Wall 5
    uvage.from_image(1200, 400, "black_blockade.png"),
    uvage.from_image(1200, 480, "black_blockade.png"),
    uvage.from_image(1200, 555, "black_blockade.png"),
    uvage.from_image(1200, 200, "black_blockade.png"),
    uvage.from_image(1200, 8, "black_blockade.png"),
    # Wall 6
    uvage.from_image(1400, 145, "black_blockade.png"),
    uvage.from_image(1400, 225, "black_blockade.png"),
    uvage.from_image(1400, 305, "black_blockade.png"),
    uvage.from_image(1400, 355, "black_blockade.png"),
    uvage.from_image(1400, 540, "black_blockade.png"),
    uvage.from_image(1400, 600, "black_blockade.png")
]
for b in black_blockades:
    b.scale_by(0.05)

# Gray blockades (Player 1)
gray_blockades = [
    uvage.from_image(400, 135, "gray_blockade.png"),
    uvage.from_image(600, 315, "gray_blockade.png"),
    uvage.from_image(800, 50, "gray_blockade.png"),
    uvage.from_image(1000, 125, "gray_blockade.png"),
    uvage.from_image(1200, 300, "gray_blockade.png"),
    uvage.from_image(1400, 50, "gray_blockade.png")
]
for g in gray_blockades:
    g.scale_by(0.05)

# Pink blockades (Player 2)
pink_blockades = [
    uvage.from_image(400, 385, "pink_blockade.png"),
    uvage.from_image(600, 130, "pink_blockade.png"),
    uvage.from_image(800, 450, "pink_blockade.png"),
    uvage.from_image(1000, 385, "pink_blockade.png"),
    uvage.from_image(1200, 105, "pink_blockade.png"),
    uvage.from_image(1400, 450, "pink_blockade.png")
]
for p in pink_blockades:
    p.scale_by(0.05)

hit_count1 = 0
hit_count2 = 0

ticker = 0

game_on = False
game_over = False

winner_pink = False
winner_gray = False

gray_break = 0
pink_break = 0

# End messages
time_out = uvage.from_text(400, 300, "Time ran out! Game Over :(", 50, "black")
pink_win = uvage.from_text(400, 300, "Player 2 wins!", 50, "pink")
gray_win = uvage.from_text(400, 300, "Player 1 wins!", 50, "gray")

# Collision boxes
box1 = uvage.from_color(player1_run.x, player1_run.y, "red", 100, 60)
box2 = uvage.from_color(player2_run.x, player2_run.y, "red", 100, 60)


def player1_running():
    global player1_run_current_frame
    global player1_move

    global player1_attack_current_frame
    global player1_move2

    global player1_move_right

    global hit_count1
    global gray_break
    global winner_gray
    global winner_pink

    global box1

    player1_move = False
    player1_move2 = False

    player1_run.move_to_stop_overlapping(topwall)
    player1_run.move_to_stop_overlapping(bottomwall)
    player1_run.move_to_stop_overlapping(leftwall)
    player1_run.move_to_stop_overlapping(rightwall)

    # Player 1 interacting with blockades
    for black in black_blockades:
        player1_run.move_to_stop_overlapping(black)

    # Breaking Player 1's blockades
    for gray in gray_blockades:
        player1_run.move_to_stop_overlapping(gray)
        if box1.touches(gray):
            if uvage.is_pressing("forward slash"):
                hit_count1 += 1
                if hit_count1 > 15:
                    gray_blockades.remove(gray)
                    hit_count1 = 0
    for pink in pink_blockades:
        player1_run.move_to_stop_overlapping(pink)

    # Player 1 controls
    if uvage.is_pressing("left arrow"):
        player1_run.x -= 3
        player1_move = True
        if player1_move_right:
            player1_run.flip()
            player1_move_right = False
    elif uvage.is_pressing("right arrow"):
        player1_run.x += 3
        player1_move = True
        if not player1_move_right:
            player1_run.flip()
            player1_move_right = True
    elif uvage.is_pressing("up arrow"):
        player1_run.y -= 3
        player1_move = True
    elif uvage.is_pressing("down arrow"):
        player1_run.y += 3
        player1_move = True
    elif uvage.is_pressing("forward slash"):
        player1_move2 = True

    # Player 1 actions
    if player1_move:
        player1_run_current_frame += 0.5
        if player1_run_current_frame >= 7:
            player1_run_current_frame = 0
        player1_run.image = player1_run_sheet[int(player1_run_current_frame)]
    elif player1_move2:
        player1_attack_current_frame += 0.5
        if player1_attack_current_frame >= 4:
            player1_attack_current_frame = 0
        player1_run.image = player1_attack_sheet[int(player1_attack_current_frame)]
    else:
        player1_run.image = player1_idle_sheet[1]

    # If Player 1 wins
    if box1.touches(potion):
        winner_gray = True
    # If PLayer 1 moves off-screen
    if box1.touches(leftwall):
       winner_pink = True


def player2_running():
    global player2_run_current_frame
    global player2_move

    global player2_attack_current_frame
    global player2_move2

    global player2_move_right

    global hit_count2

    global potion

    global game_on
    global game_over
    global winner_gray
    global winner_pink

    global hit_count2
    global box2

    player2_move = False
    player2_move2 = False

    player2_run.move_to_stop_overlapping(topwall)
    player2_run.move_to_stop_overlapping(bottomwall)
    player2_run.move_to_stop_overlapping(leftwall)
    player2_run.move_to_stop_overlapping(rightwall)
    # Player 2 interacting with blockades
    for black in black_blockades:
        player2_run.move_to_stop_overlapping(black)
    for gray in gray_blockades:
        player2_run.move_to_stop_overlapping(gray)
        # Breaking Player 2's blockades
    for pink in pink_blockades:
        player2_run.move_to_stop_overlapping(pink)
        if box2.touches(pink):
            if uvage.is_pressing("q"):
                hit_count2 += 1
                if hit_count2 > 15:
                    pink_blockades.remove(pink)
                    hit_count2 = 0

    # Player 2 controls
    if uvage.is_pressing("a"):
        player2_run.x -= 3
        player2_move = True
        if player2_move_right:
            player2_run.flip()
            player2_move_right = False
    elif uvage.is_pressing("d"):
        player2_run.x += 3
        player2_move = True
        if not player2_move_right:
            player2_run.flip()
            player2_move_right = True
    elif uvage.is_pressing("w"):
        player2_run.y -= 3
        player2_move = True
    elif uvage.is_pressing("s"):
        player2_run.y += 3
        player2_move = True
    elif uvage.is_pressing("q"):
        player2_move2 = True

    # Player 2 actions
    if player2_move:
        player2_run_current_frame += 0.5
        if player2_run_current_frame >= 7:
            player2_run_current_frame = 0
        player2_run.image = player2_run_sheet[int(player2_run_current_frame)]
    elif player2_move2:
        player2_attack_current_frame += 0.5
        if player2_attack_current_frame >= 4:
            player2_attack_current_frame = 0
        player2_run.image = player2_attack_sheet[int(player2_attack_current_frame)]
    else:
        player2_run.image = player2_idle_sheet[1]

    # If Player 2 wins
    if box2.touches(potion):
        winner_pink = True
    # If Player 2 moves off-screen
    if box2.touches(leftwall):
        winner_gray = True


def tick():
    global game_on
    global game_over
    global ticker
    global winner_pink
    global winner_gray
    global pink_win
    global pink_break
    global time_out

    camera.draw(background)
    # Starting the game
    if uvage.is_pressing("space"):
        game_on = True
        winner_pink = False
        winner_gray = False
    if game_on:
        # Creating the game screen
        camera.clear("white")
        camera.move(1, 0)

        topwall.move(1, 0)
        bottomwall.move(1, 0)
        leftwall.move(1, 0)
        rightwall.move(1, 0)

        time_out.move(1, 0)
        gray_win.move(1, 0)
        pink_win.move(1, 0)

        # Setting the timer
        timer = uvage.from_text(camera.x, 50, str(45 - ticker // 30), 70, "white")
        timer.move(1, 0)
        ticker += 1

        player1_running()
        player2_running()

        camera.draw(background)
        camera.draw(background2)
        camera.draw(background3)
        camera.draw(player1_run)
        camera.draw(player2_run)

        # Creating collision boxes
        # camera.draw(box1)             # For reference
        # camera.draw(box2)
        box1.y = player1_run.y + 30
        box2.y = player2_run.y + 30
        box1.x = player1_run.x + 30
        box2.x = player2_run.x + 30

        camera.draw(potion)
        camera.draw(topwall)
        camera.draw(bottomwall)
        camera.draw(leftwall)
        camera.draw(rightwall)

        # Drawing the blockades
        for gray in gray_blockades:
            camera.draw(gray)
        for black in black_blockades:
            camera.draw(black)
        for pink in pink_blockades:
            camera.draw(pink)

        camera.draw(timer)

        # Game ending scenarios
        if ticker // 30 == 45 and not (winner_pink or winner_gray):
            game_on = False
            game_over = False
        if winner_pink:
            camera.clear("black")
            camera.draw(background)
            camera.draw(background2)
            camera.draw(background3)
            camera.draw(pink_win)

            if camera.x == 1700:
                game_on = False

        if winner_gray:
            camera.clear("black")
            camera.draw(background)
            camera.draw(background2)
            camera.draw(background3)
            camera.draw(gray_win)

            if camera.x == 1700:
                game_on = False

    if game_over:
        camera.clear("black")
        camera.draw(background)
        camera.draw(background2)
        camera.draw(background3)

    if not game_on:
        camera.clear("black")
        camera.draw(background)
        camera.draw(background2)
        camera.draw(background3)

        if (winner_gray == False) and (winner_pink == False):
            camera.draw(time_out)

        camera.draw(instructions_box)
        camera.draw(instructions)
        camera.draw(instructions1)
        camera.draw(instructions2)
        camera.draw(instructions3)
        camera.draw(instructions4)
        camera.draw(instructions5)
        camera.draw(instructions6)
        camera.draw(instructions7)

    camera.display()


uvage.timer_loop(30, tick)